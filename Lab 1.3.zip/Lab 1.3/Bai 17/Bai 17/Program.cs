﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Nhap so luong hinh tron: ");
        int n = int.Parse(Console.ReadLine());

        List<HinhTron> hinhTronList = new List<HinhTron>();

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap hinh tron {i + 1}:");
            HinhTron hinhTron = new HinhTron();
            hinhTron.Nhap();
            hinhTronList.Add(hinhTron);
        }

        HinhTron hinhTronGiaoNhauNhieuNhat = TimHinhTronGiaoNhauNhieuNhat(hinhTronList);

        if (hinhTronGiaoNhauNhieuNhat != null)
        {
            Console.WriteLine("Hinh tron giao nhau nhieu nhat:");
            hinhTronGiaoNhauNhieuNhat.Xuat();
        }
        else
        {
            Console.WriteLine("Khong co hinh tron nao giao nhau.");
        }
    }

    static HinhTron TimHinhTronGiaoNhauNhieuNhat(List<HinhTron> hinhTronList)
    {
        int maxGiaoNhau = 0;
        HinhTron hinhTronGiaoNhauNhieuNhat = null;

        foreach (HinhTron h1 in hinhTronList)
        {
            int countGiaoNhau = 0;
            foreach (HinhTron h2 in hinhTronList)
            {
                if (h1 != h2 && h1.KiemTraGiaoNhau(h2))
                {
                    countGiaoNhau++;
                }
            }

            if (countGiaoNhau > maxGiaoNhau)
            {
                maxGiaoNhau = countGiaoNhau;
                hinhTronGiaoNhauNhieuNhat = h1;
            }
        }

        return hinhTronGiaoNhauNhieuNhat;
    }
}

// Lớp Diem  
class Diem
{
    public float HoanhDo { get; set; }
    public float TungDo { get; set; }

    // Toán tử tạo lập  
    public Diem() : this(0, 0) { }

    public Diem(float x, float y)
    {
        HoanhDo = x;
        TungDo = y;
    }

    // Phương thức in một đối tượng Diem  
    public void Xuat()
    {
        Console.WriteLine($"Diem: ({HoanhDo}, {TungDo})");
    }

    // Tính khoảng cách giữa hai điểm  
    public float KhoangCach(Diem other)
    {
        return (float)Math.Sqrt(Math.Pow(HoanhDo - other.HoanhDo, 2) + Math.Pow(TungDo - other.TungDo, 2));
    }
}

// Lớp HinhTron  
class HinhTron
{
    private Diem Tam { get; set; } // Tâm hình tròn  
    private float BanKinh { get; set; } // Bán kính hình tròn  

    // Các toán tử tạo lập  
    public HinhTron() : this(new Diem(), 1) { }

    public HinhTron(Diem d, float bk)
    {
        Tam = d;
        BanKinh = bk;
    }

    // Nhập thông tin hình tròn  
    public void Nhap()
    {
        Console.Write("Nhap hoanh do tam: ");
        float x = float.Parse(Console.ReadLine());
        Console.Write("Nhap tung do tam: ");
        float y = float.Parse(Console.ReadLine());
        Tam = new Diem(x, y);
        Console.Write("Nhap ban kinh: ");
        BanKinh = float.Parse(Console.ReadLine());
    }

    // Tính chu vi hình tròn  
    public float TinhChuVi()
    {
        return 2 * (float)Math.PI * BanKinh;
    }

    // Tính diện tích hình tròn  
    public float TinhDienTich()
    {
        return (float)Math.PI * BanK