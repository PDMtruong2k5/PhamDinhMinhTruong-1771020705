﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        List<HocSinh> danhSachHocSinh = new List<HocSinh>();

        Console.Write("Nhap so luong hoc sinh: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\nNhap thong tin hoc sinh {i + 1}:");
            HocSinh hocSinh = NhapHocSinh();
            danhSachHocSinh.Add(hocSinh);
        }

        // Hiển thị thông tin về những học sinh nam có điểm môn kỹ thuật không nhỏ hơn 8  
        Console.WriteLine("\nDanh sach hoc sinh nam co diem ky thuat >= 8:");
        foreach (var hs in danhSachHocSinh)
        {
            if (hs.GioiTinh == "Nam" && hs.DiemKyThuat >= 8)
            {
                hs.InThongTin();
            }
        }

        // In danh sách học sinh nam trước rồi đến học sinh nữ  
        Console.WriteLine("\nDanh sach hoc sinh:");
        Console.WriteLine("Hocsinh nam:");
        foreach (var hs in danhSachHocSinh)
        {
            if (hs.GioiTinh == "Nam")
            {
                hs.InThongTin();
            }
        }

        Console.WriteLine("\nHocsinh nu:");
        foreach (var hs in danhSachHocSinh)
        {
            if (hs.GioiTinh == "Nu")
            {
                hs.InThongTin();
            }
        }
    }

    static HocSinh NhapHocSinh()
    {
        Console.Write("Nhap ho ten: ");
        string hoTen = Console.ReadLine();

        Console.Write("Nhap gioi tinh (Nam/Nu): ");
        string gioiTinh = Console.ReadLine();

        Console.Write("Nhap diem toan: ");
        double diemToan = double.Parse(Console.ReadLine());

        Console.Write("Nhap diem ly: ");
        double diemLy = double.Parse(Console.ReadLine());

        Console.Write("Nhap diem hoa: ");
        double diemHoa = double.Parse(Console.ReadLine());

        double diemKyThuat = 0;
        if (gioiTinh.Equals("Nam", StringComparison.OrdinalIgnoreCase))
        {
            Console.Write("Nhap diem ky thuat: ");
            diemKyThuat = double.Parse(Console.ReadLine());
        }
        else
        {
            Console.Write("Nhap diem nu cong: ");
            diemKyThuat = double.Parse(Console.ReadLine());
        }

        return new HocSinh(hoTen, gioiTinh, diemToan, diemLy, diemHoa, diemKyThuat);
    }
}

// Lớp HocSinh  
class HocSinh
{
    public string HoTen { get; set; }
    public string GioiTinh { get; set; }
    public double DiemToan { get; set; }
    public double DiemLy { get; set; }
    public double DiemHoa { get; set; }
    public double DiemKyThuat { get; set; } // Hoặc diem nu cong cho hoc sinh nu  

    public HocSinh(string hoTen, string gioiTinh, double diemToan, double diemLy, double diemHoa, double diemKyThuat)
    {
        HoTen = hoTen;
        GioiTinh = gioiTinh;
        DiemToan = diemToan;
        DiemLy = diemLy;
        DiemHoa = diemHoa;
        DiemKyThuat = diemKyThuat;
    }

    public void InThongTin()
    {
        Console.WriteLine($"Ho ten: {HoTen}, Gioi tinh: {GioiTinh}, Diem Toan: {DiemToan}, Diem Ly: {DiemLy}, Diem Hoa: {DiemHoa}, Diem Ky Thuat: {DiemKyThuat}");
    }
}