﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        QLHS qlhs = new QLHS();
        qlhs.Run();
    }
}

// Lớp Nguoi  
class Nguoi
{
    public string HoTen { get; set; }
    public int Tuoi { get; set; }
    public int NamSinh { get; set; }
    public string QueQuan { get; set; }
    public string GioiTinh { get; set; }

    public void Nhap()
    {
        Console.Write("Nhap ho ten: ");
        HoTen = Console.ReadLine();
        Console.Write("Nhap tuoi: ");
        Tuoi = int.Parse(Console.ReadLine());
        Console.Write("Nhap nam sinh: ");
        NamSinh = int.Parse(Console.ReadLine());
        Console.Write("Nhap que quan: ");
        QueQuan = Console.ReadLine();
        Console.Write("Nhap gioi tinh: ");
        GioiTinh = Console.ReadLine();
    }

    public void HienThi()
    {
        Console.WriteLine($"Ho ten: {HoTen}, Tuoi: {Tuoi}, Nam sinh: {NamSinh}, Que quan: {QueQuan}, Gioi tinh: {GioiTinh}");
    }
}

// Lớp HSHocSinh  
class HSHocSinh
{
    public string Lop { get; set; }
    public string Khoahoc { get; set; }
    public string KyHoc { get; set; }
    public Nguoi HocSinh { get; set; }

    public HSHocSinh()
    {
        HocSinh = new Nguoi();
    }

    public void Nhap()
    {
        Console.Write("Nhap lop: ");
        Lop = Console.ReadLine();
        Console.Write("Nhap khoahoc: ");
        Khoahoc = Console.ReadLine();
        Console.Write("Nhap ky hoc: ");
        KyHoc = Console.ReadLine();
        Console.WriteLine("Nhap thong tin hoc sinh:");
        HocSinh.Nhap();
    }

    public void HienThi()
    {
        Console.WriteLine($"Lop: {Lop}, Khoahoc: {Khoahoc}, Ky hoc: {KyHoc}");
        HocSinh.HienThi();
    }
}

// Lớp QLHS  
class QLHS
{
    private List<HSHocSinh> danhSachHocSinh;

    public QLHS()
    {
        danhSachHocSinh = new List<HSHocSinh>();
    }

    public void Run()
    {
        int luaChon;
        do
        {
            Console.WriteLine("===== QUAN LY HOC SINH =====");
            Console.WriteLine("1. Nhap danh sach hoc sinh");
            Console.WriteLine("2. Hien thi hoc sinh nu sinh nam 1985");
            Console.WriteLine("3. Tim kiem hoc sinh theo que quan");
            Console.WriteLine("4. Thoat");
            Console.Write("Nhap lua chon: ");
            luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    NhapDanhSach();
                    break;
                case 2:
                    HienThiHocSinhNu1985();
                    break;
                case 3:
                    TimKiemHocSinhTheoQueQuan();
                    break;
                case 4:
                    Console.WriteLine("Thoat khoi chuong trinh.");
                    break;
                default:
                    Console.WriteLine("Lua chon khong hop le. Vui long chon lai.");
                    break;
            }
        } while (luaChon != 4);
    }

    private void NhapDanhSach()
    {
        Console.Write("Nhap so luong hoc sinh: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console