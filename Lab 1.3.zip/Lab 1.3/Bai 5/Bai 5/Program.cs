﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        KhachSan khachSan = new KhachSan();
        khachSan.Run();
    }
}

// Lớp Nguoi  
class Nguoi
{
    public string HoTen { get; set; }
    public int NamSinh { get; set; }
    public string SoCMND { get; set; }

    public void Nhap()
    {
        Console.Write("Nhap ho ten: ");
        HoTen = Console.ReadLine();
        Console.Write("Nhap nam sinh: ");
        NamSinh = int.Parse(Console.ReadLine());
        Console.Write("Nhap so CMND: ");
        SoCMND = Console.ReadLine();
    }

    public void HienThi()
    {
        Console.WriteLine($"Ho ten: {HoTen}, Nam sinh: {NamSinh}, So CMND: {SoCMND}");
    }
}

// Lớp KhachSan  
class KhachSan
{
    public string LoaiPhong { get; set; }
    public double GiaPhong { get; set; }
    public int SoNgayTro { get; set; }
    public List<Nguoi> KhachTro { get; set; }

    public KhachSan()
    {
        KhachTro = new List<Nguoi>();
    }

    public void Nhap()
    {
        Console.Write("Nhap loai phong: ");
        LoaiPhong = Console.ReadLine();
        Console.Write("Nhap gia phong: ");
        GiaPhong = double.Parse(Console.ReadLine());
        Console.Write("Nhap so ngay tro: ");
        SoNgayTro = int.Parse(Console.ReadLine());

        Nguoi nguoi = new Nguoi();
        nguoi.Nhap();
        KhachTro.Add(nguoi);
    }

    public void HienThi()
    {
        Console.WriteLine($"Loai phong: {LoaiPhong}, Gia phong: {GiaPhong}, So ngay tro: {SoNgayTro}");
        foreach (var nguoi in KhachTro)
        {
            nguoi.HienThi();
        }
        Console.WriteLine("---------------------------");
    }

    public double TinhTien()
    {
        return SoNgayTro * GiaPhong;
    }

    public bool TimKiem(string hoTen)
    {
        return KhachTro.Any(nguoi => nguoi.HoTen.Equals(hoTen, StringComparison.OrdinalIgnoreCase));
    }

    public void HienThiKhachTro()
    {
        foreach (var nguoi in KhachTro)
        {
            nguoi.HienThi();
        }
    }

    public void Run()
    {
        int luaChon;
        do
        {
            Console.WriteLine("===== QUAN LY KHACH SAN =====");
            Console.WriteLine("1. Nhap thong tin khach tro");
            Console.WriteLine("2. Hien thi thong tin khach tro");
            Console.WriteLine("3. Tim kiem khach tro theo ho ten");
            Console.WriteLine("4. Tinh tien cho khach hang");
            Console.WriteLine("5. Thoat");
            Console.Write("Nhap lua chon: ");
            luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    Nhap();
                    break;
                case 2:
                    HienThi();
                    break;
                case 3:
                    TimKiemKhachTro();
                    break;
                case 4:
                    TinhTienChoKhach();
                    break;
                case 5:
                    Console.WriteLine("Thoat khoi chuong trinh.");
                    break;
                default:
                    Console.WriteLine("Lua chon khong hop le. Vui long chon lai.");
                    break;
            }
        } while (luaChon != 5);
    }

    private void TimKiemKhachTro()
    {
        Console.Write("Nhap ho ten