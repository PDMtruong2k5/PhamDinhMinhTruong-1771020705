﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        List<THISINH> danhSachThiSinh = new List<THISINH>();

        Console.Write("Nhap so luong thi sinh: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\nNhap thong tin thi sinh {i + 1}:");
            THISINH thiSinh = new THISINH();
            thiSinh.Nhap();
            danhSachThiSinh.Add(thiSinh);
        }

        Console.WriteLine("\nCac thi sinh co tong diem > 15:");
        var thiSinhHanhPhuc = danhSachThiSinh.Where(ts => ts.TinhTongDiem() > 15).ToList();
        foreach (var ts in thiSinhHanhPhuc)
        {
            ts.InThongTin();
        }

        // Sắp xếp danh sách theo tổng điểm giảm dần  
        danhSachThiSinh = danhSachThiSinh.OrderByDescending(ts => ts.TinhTongDiem()).ToList();

        Console.WriteLine("\nDanh sach thi sinh sau khi sap xep:");
        Console.WriteLine("-------------------------------------------------------------");
        Console.WriteLine("|   Ho Ten   |   Que Quan   |   So Bao Danh   |  Diem Toan  |  Diem Ly  |  Diem Hoa  |");
        Console.WriteLine("-------------------------------------------------------------");
        foreach (var ts in danhSachThiSinh)
        {
            ts.InThongTinBieuDo();
        }
        Console.WriteLine("-------------------------------------------------------------");
    }
}

// Cấu trúc họ tên  
struct HoTen
{
    public string Ho;
    public string TenDem;
    public string Ten;
}

// Cấu trúc quê quán  
struct QueQuan
{
    public string Xa;
    public string Huyen;
    public string Tinh;
}

// Cấu trúc điểm thi  
struct DiemThi
{
    public float Toan;
    public float Ly;
    public float Hoa;
}

// Lớp THISINH  
class THISINH
{
    public HoTen HoTen { get; set; }
    public QueQuan QueQuan { get; set; }
    public string Truong { get; set; }
    public int Tuoi { get; set; }
    public string SoBaoDanh { get; set; }
    public DiemThi DiemThi { get; set; }

    // Nhập thông tin thí sinh  
    public void Nhap()
    {
        Console.Write("Nhap ho: ");
        HoTen.Ho = Console.ReadLine();
        Console.Write("Nhap ten dem: ");
        HoTen.TenDem = Console.ReadLine();
        Console.Write("Nhap ten: ");
        HoTen.Ten = Console.ReadLine();

        Console.Write("Nhap que xa: ");
        QueQuan.Xa = Console.ReadLine();
        Console.Write("Nhap que huyen: ");
        QueQuan.Huyen = Console.ReadLine();
        Console.Write("Nhap que tinh: ");
        QueQuan.Tinh = Console.ReadLine();

        Console.Write("Nhap truong: ");
        Truong = Console.ReadLine();
        Console.Write("Nhap tuoi: ");
        Tuoi = int.Parse(Console.ReadLine());
        Console.Write("Nhap so bao danh: ");
        SoBaoDanh = Console.ReadLine();

        Console.Write("Nhap diem thi toan: ");
        DiemThi.Toan = float.Parse(Console.ReadLine());
        Console.Write("Nhap diem thi ly: ");
        DiemThi.Ly = float.Parse(Console.ReadLine());
        Console.Write("Nhap diem thi hoa: ");
        DiemThi.Hoa = float.Parse(Console.ReadLine());
    }

    // Tính tổng điểm ba môn  
    public float TinhTongDiem()
    {
        return DiemThi.Toan + DiemThi.Ly + DiemThi.Hoa;
    }

    // In thông tin thí sinh  
    public void InThongTin()
    {
        Console.WriteLine($"Ho ten: {HoTen.Ho} {HoTen.TenDem} {HoTen.Ten}, " +
                          $"Que quan: {QueQuan.Xa}, {QueQuan.Huyen}, {QueQuan.Tinh}, " +
                          $"So bao danh: {SoBaoDanh}, Tong diem: {TinhTongDiem():F2}");
    }

    // In thông tin