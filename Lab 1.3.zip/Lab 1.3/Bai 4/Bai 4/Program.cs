﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        KhuPho khuPho = new KhuPho();
        khuPho.Run();
    }
}

// Lớp Nguoi  
class Nguoi
{
    public string SoCMND { get; set; }
    public string HoTen { get; set; }
    public int Tuoi { get; set; }
    public int NamSinh { get; set; }
    public string NgheNghiep { get; set; }

    public void Nhap()
    {
        Console.Write("Nhap so CMND: ");
        SoCMND = Console.ReadLine();
        Console.Write("Nhap ho ten: ");
        HoTen = Console.ReadLine();
        Console.Write("Nhap tuoi: ");
        Tuoi = int.Parse(Console.ReadLine());
        Console.Write("Nhap nam sinh: ");
        NamSinh = int.Parse(Console.ReadLine());
        Console.Write("Nhap nghe nghiep: ");
        NgheNghiep = Console.ReadLine();
    }

    public void HienThi()
    {
        Console.WriteLine($"So CMND: {SoCMND}, Ho ten: {HoTen}, Tuoi: {Tuoi}, Nam sinh: {NamSinh}, Nghe nghiep: {NgheNghiep}");
    }
}

// Lớp HoDan  
class HoDan
{
    public int SoThanhVien { get; set; }
    public string SoNha { get; set; }
    public List<Nguoi> ThanhVien { get; set; }

    public HoDan()
    {
        ThanhVien = new List<Nguoi>();
    }

    public void Nhap()
    {
        Console.Write("Nhap so nha: ");
        SoNha = Console.ReadLine();
        Console.Write("Nhap so thanh vien: ");
        SoThanhVien = int.Parse(Console.ReadLine());

        for (int i = 0; i < SoThanhVien; i++)
        {
            Console.WriteLine($"Nhap thong tin cho thanh vien {i + 1}:");
            Nguoi nguoi = new Nguoi();
            nguoi.Nhap();
            ThanhVien.Add(nguoi);
        }
    }

    public void HienThi()
    {
        Console.WriteLine($"So nha: {SoNha}, So thanh vien: {SoThanhVien}");
        foreach (var nguoi in ThanhVien)
        {
            nguoi.HienThi();
        }
        Console.WriteLine("---------------------------");
    }
}

// Lớp KhuPho  
class KhuPho
{
    private List<HoDan> danhSachHoDan;

    public KhuPho()
    {
        danhSachHoDan = new List<HoDan>();
    }

    public void Run()
    {
        int luaChon;
        do
        {
            Console.WriteLine("===== QUAN LY KHU PHO =====");
            Console.WriteLine("1. Nhap thong tin ho dan");
            Console.WriteLine("2. Tim kiem ho dan theo ho ten hoac so nha");
            Console.WriteLine("3. Hien thi thong tin tat ca ho dan");
            Console.WriteLine("4. Thoat");
            Console.Write("Nhap lua chon: ");
            luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    NhapHoDan();
                    break;
                case 2:
                    TimKiemHoDan();
                    break;
                case 3:
                    HienThiTatCaHoDan();
                    break;
                case 4:
                    Console.WriteLine("Thoat khoi chuong trinh.");
                    break;
                default:
                    Console.WriteLine("Lua chon khong hop le. Vui long chon lai.");
                    break;
            }
        } while (luaChon != 4);
    }

    private void NhapHoDan()
    {
        HoDan hoDan = new HoDan();
        hoDan.Nhap();
        danhSachHo