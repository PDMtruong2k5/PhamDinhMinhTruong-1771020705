﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        const double LUONG_CO_BAN = 1050000; // Lương cơ bản  

        List<CoQuan> danhSachCaNhan = new List<CoQuan>();
        Console.Write("Nhap so luong ca nhan: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap thong tin ca nhan {i + 1}:");
            CoQuan caNhan = new CoQuan();
            caNhan.Nhap();
            danhSachCaNhan.Add(caNhan);
        }

        while (true)
        {
            Console.WriteLine("\n===== MENU =====");
            Console.WriteLine("1. Hien thi ca nhan co don vi Phong tai chinh");
            Console.WriteLine("2. Tim kiem ca nhan theo ho ten");
            Console.WriteLine("3. Thoat");
            Console.Write("Nhap lua chon: ");
            int luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    HienThiCaNhanPhongTaiChinh(danhSachCaNhan);
                    break;

                case 2:
                    TimKiemCaNhanTheoHoTen(danhSachCaNhan);
                    break;

                case 3:
                    Console.WriteLine("Thoat khoi chuong trinh.");
                    return;

                default:
                    Console.WriteLine("Lua chon khong hop le. Vui long chon lai.");
                    break;
            }
        }
    }

    static void HienThiCaNhanPhongTaiChinh(List<CoQuan> danhSach)
    {
        Console.WriteLine("Danh sach ca nhan co don vi Phong tai chinh:");
        foreach (var caNhan in danhSach)
        {
            if (caNhan.DonViCoQuan.Equals("Phong tai chinh", StringComparison.OrdinalIgnoreCase))
            {
                caNhan.In();
                Console.WriteLine($"Luong: {caNhan.TinhLuong():F0} VNĐ"); // Hiển thị lương  
            }
        }
    }

    static void TimKiemCaNhanTheoHoTen(List<CoQuan> danhSach)
    {
        Console.Write("Nhap ho ten can tim: ");
        string hoTen = Console.ReadLine();
        CoQuan caNhanTimThay = danhSach.Find(caNhan => caNhan.HoTen.Equals(hoTen, StringComparison.OrdinalIgnoreCase));

        if (caNhanTimThay != null)
        {
            caNhanTimThay.In();
            Console.WriteLine($"Luong: {caNhanTimThay.TinhLuong():F0} VNĐ"); // Hiển thị lương  
        }
        else
        {
            Console.WriteLine("Khong tim thay ca nhan.");
        }
    }
}

// Lớp Nguoi  
class Nguoi
{
    public string HoTen { get; set; }
    public bool GioiTinh { get; set; } // true: Nam, false: Nu  
    public int Tuoi { get; set; }

    // Toán tử tạo lập  
    public Nguoi()
    {
        HoTen = "Chua xac dinh";
        GioiTinh = true; // Mặc định là Nam  
        Tuoi = 0;
    }

    public Nguoi(string hoTen, bool gioiTinh, int tuoi)
    {
        HoTen = hoTen;
        GioiTinh = gioiTinh;
        Tuoi = tuoi;
    }

    // Phương thức in thông tin cá nhân  
    public virtual void In()
    {
        string gioiTinhStr = GioiTinh ? "Nam" : "Nu";
        Console.WriteLine($"Ho ten: {HoTen}, Gioi tinh: {gioiTinhStr}, Tuoi: {Tuoi}");
    }
}

// Lớp CoQuan  
class CoQuan : Nguoi
{
    public string DonViCoQuan { get; set; } // Đơn vị công tác  
    public double HeSoLuong { get; set; } // Hệ số lương  

    // Toán tử tạo lập  
    public CoQuan() : base()
    {
        DonViCoQuan = "Chua xac dinh";
        HeSoLuong = 1.0; // M