﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Nhap so luong tam giac: ");
        int n = int.Parse(Console.ReadLine());

        List<TamGiac> tamGiacList = new List<TamGiac>();

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap tam giac {i + 1}:");
            TamGiac tamGiac = new TamGiac();
            tamGiac.Nhap();
            tamGiacList.Add(tamGiac);
        }

        double tongChuVi = 0;
        double tongDienTich = 0;

        foreach (TamGiac tg in tamGiacList)
        {
            tongChuVi += tg.TinhChuVi();
            tongDienTich += tg.TinhDienTich();
        }

        Console.WriteLine($"Tong chu vi: {tongChuVi}");
        Console.WriteLine($"Tong dien tich: {tongDienTich}");
    }
}

// Lớp Diem  
class Diem
{
    public double HoanhDo { get; set; }
    public double TungDo { get; set; }

    // Toán tử tạo lập  
    public Diem() : this(0, 0) { }

    public Diem(double x, double y)
    {
        HoanhDo = x;
        TungDo = y;
    }

    // Phương thức in một đối tượng Diem  
    public void In()
    {
        Console.WriteLine($"Diem: ({HoanhDo}, {TungDo})");
    }

    // Tính khoảng cách giữa hai điểm  
    public double KhoangCach(Diem other)
    {
        return Math.Sqrt(Math.Pow(HoanhDo - other.HoanhDo, 2) + Math.Pow(TungDo - other.TungDo, 2));
    }
}

// Lớp TamGiac  
class TamGiac
{
    private Diem d1;
    private Diem d2;
    private Diem d3;

    // Toán tử tạo lập  
    public TamGiac()
    {
        d1 = new Diem();
        d2 = new Diem();
        d3 = new Diem();
    }

    public TamGiac(Diem d1, Diem d2, Diem d3)
    {
        this.d1 = d1;
        this.d2 = d2;
        this.d3 = d3;
    }

    // Phương thức nhập tam giác  
    public void Nhap()
    {
        Console.WriteLine("Nhap diem d1:");
        d1 = NhapDiem();
        Console.WriteLine("Nhap diem d2:");
        d2 = NhapDiem();
        Console.WriteLine("Nhap diem d3:");
        d3 = NhapDiem();
    }

    private Diem NhapDiem()
    {
        Console.Write("Nhap hoanh do: ");
        double x = double.Parse(Console.ReadLine());
        Console.Write("Nhap tung do: ");
        double y = double.Parse(Console.ReadLine());
        return new Diem(x, y);
    }

    // Tính diện tích tam giác  
    public double TinhDienTich()
    {
        double a = d1.KhoangCach(d2);
        double b = d2.KhoangCach(d3);
        double c = d3.KhoangCach(d1);
        double p = (a + b + c) / 2; // Nửa chu vi  

        return Math.Sqrt(p * (p - a) * (p - b) * (p - c)); // Công thức Heron  
    }

    // Tính chu vi của tam giác  
    public double TinhChuVi()
    {
        double a = d1.KhoangCach(d2);
        double b = d2.KhoangCach(d3);
        double c = d3.KhoangCach(d1);
        return a + b + c;
    }
}