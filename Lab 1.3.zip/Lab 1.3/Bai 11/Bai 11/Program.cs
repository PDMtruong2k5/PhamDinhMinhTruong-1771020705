﻿using System;

class Program
{
    static void Main(string[] args)
    {
        SoPhuc A = new SoPhuc();
        SoPhuc B = new SoPhuc();

        Console.WriteLine("Nhap so phuc A:");
        A.Nhap();
        Console.WriteLine("Nhap so phuc B:");
        B.Nhap();

        int luaChon;
        do
        {
            Console.WriteLine("===== MENU =====");
            Console.WriteLine("1. Cong hai so phuc");
            Console.WriteLine("2. Hieu hai so phuc");
            Console.WriteLine("3. Tich hai so phuc");
            Console.WriteLine("4. Thuong hai so phuc");
            Console.WriteLine("5. Thoat");
            Console.Write("Nhap lua chon: ");
            luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    SoPhuc tong = A.Cong(B);
                    Console.WriteLine($"Tong hai so phuc A + B = {tong}");
                    break;
                case 2:
                    SoPhuc hieu = A.Hieu(B);
                    Console.WriteLine($"Hieu hai so phuc A - B = {hieu}");
                    break;
                case 3:
                    SoPhuc tich = A.Nhan(B);
                    Console.WriteLine($"Tich hai so phuc A * B = {tich}");
                    break;
                case 4:
                    SoPhuc thuong = A.Chia(B);
                    Console.WriteLine($"Thuong hai so phuc A / B = {thuong}");
                    break;
                case 5:
                    Console.WriteLine("Thoat khoi chuong trinh.");
                    break;
                default:
                    Console.WriteLine("Lua chon khong hop le. Vui long chon lai.");
                    break;
            }
        } while (luaChon != 5);
    }
}

// Lớp SoPhuc  
class SoPhuc
{
    private double phanThuc; // Phần thực  
    private double phanAo;    // Phần ảo  

    // Hàm tạo mặc định  
    public SoPhuc()
    {
        phanThuc = 0;
        phanAo = 0;
    }

    // Hàm tạo với hai đối số  
    public SoPhuc(double a, double b)
    {
        phanThuc = a;
        phanAo = b;
    }

    // Phương thức nhập số phức  
    public void Nhap()
    {
        Console.Write("Nhap phan thuc: ");
        phanThuc = double.Parse(Console.ReadLine());
        Console.Write("Nhap phan ao: ");
        phanAo = double.Parse(Console.ReadLine());
    }

    // Phương thức hiển thị số phức  
    public override string ToString()
    {
        return $"{phanThuc} + {phanAo}i";
    }

    // Phương thức cộng hai số phức  
    public SoPhuc Cong(SoPhuc b)
    {
        return new SoPhuc(this.phanThuc + b.phanThuc, this.phanAo + b.phanAo);
    }

    // Phương thức hiệu hai số phức  
    public SoPhuc Hieu(SoPhuc b)
    {
        return new SoPhuc(this.phanThuc - b.phanThuc, this.phanAo - b.phanAo);
    }

    // Phương thức nhân hai số phức  
    public SoPhuc Nhan(SoPhuc b)
    {
        double thuc = this.phanThuc * b.phanThuc - this.phanAo * b.phanAo;
        double ao = this.phanThuc * b.phanAo + this.phanAo * b.phanThuc;
        return new SoPhuc(thuc, ao);
    }

    // Phương thức chia hai số phức  
    public SoPhuc Chia(SoPhuc b)
    {
        double mau = b.phanThuc * b.phanThuc + b.phanAo * b.phanAo;
        if (mau == 0)
        {
            throw new DivideByZeroException("Khong the chia cho so phuc bang 0.");
        }
        double thuc = (this.phanThuc * b.phanTh